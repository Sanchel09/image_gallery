import models from "../models/index";

export const get = async () => {
  try {
    const categories = await models.Category.findAll();
    return categories;
  } catch (error) {
    throw new Error(error.message);
  }
};

export const getById = async (data) => {
  try {
    const category = await models.Category.findOne({ where: { id: data.id } });
    return category;
  } catch (err) {
    return new Error(err.message);
  }
};

export const insert = async (data) => {
  try {
    // Using for...of to handle async operations sequentially
    for (const datum of data) {
      await models.Category.create({
        name: datum.name,
        description: datum.description,
      });
    }
    return { message: "Data has been successfully inserted" };
  } catch (err) {
    throw new Error(err.message); // Throw error to handle at controller level
  }
};

export const deleteData = async (data) => {
  try {
    const category = await models.Category.findOne({ where: { id: data.id } });
    if (!category) throw new Error("No data found");

    const result = await models.Category.destroy({
      where: { id: data.id },
    });
    return result;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const updateData = async (data, updateId) => {
  try {
    const category = await models.Category.findOne({ where: { id: updateId } });
    if (!category) throw new Error("No data found");

    const result = await models.Category.update(
      {
        name: data.name,
        description: data.description,
      },
      { where: { id: updateId } }
    );
    return result;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const fetchSubCategories = async (id) => {
  try {
    const category = await models.Category.findByPk(id, {
      include: [
        {
          model: models.SubCategory,
          as: "subcategories",
        },
      ],
    });
    if (!category) throw new Error("No Category Found");
    return category;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const fetchFolders = async (id) => {
  try {
    const category = await models.Category.findByPk(id, {
      include: [
        {
          model: models.Folder,
          as: "folders",
        },
      ],
    });
    if (!category) throw new Error("No Category Found");
    return category;
  } catch (error) {
    throw new Error(error.message);
  }
};
