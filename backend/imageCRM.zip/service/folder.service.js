import models from "../models/index";

const BASE_URL = process.env.BASE_URL || "http://localhost:5000";

export const get = async () => {
  try {
    const folders = await models.Folder.findAll({
      include: [
        {
          model: models.Category,
          as: "category",
        },
        {
          model: models.SubCategory,
          as: "subCategory",
        },
      ],
    });
    return folders;
  } catch (error) {
    throw new Error(error.message);
  }
};

export const getById = async (data) => {
  try {
    const folder = await models.Folder.findOne({
      include: [
        {
          model: models.Category,
          as: "category",
        },
        {
          model: models.SubCategory,
          as: "subCategory",
        },
      ],
      where: { id: data.id },
    });
    return folder;
  } catch (err) {
    return new Error(err.message);
  }
};

export const insert = async (datum) => {
  try {
    // Using for...of to handle async operations sequentially
    // for (const datum of data) {
    console.log(datum);
    await models.Folder.create({
      name: datum.name,
      category_id: datum.categoryId,
      sub_category_id: datum.subCategoryId,
    });
    // }
    return { message: "Data has been successfully inserted" };
  } catch (err) {
    throw new Error(err.message); // Throw error to handle at controller level
  }
};

export const updateData = async (data, updateId) => {
  try {
    const folder = await models.Folder.findOne({ where: { id: updateId } });
    if (!folder) throw new Error("No data found");

    const result = await models.Folder.update(
      {
        name: data.name,
        category_id: data.category_id,
        sub_category_id: data.sub_category_id,
      },
      { where: { id: updateId } },
    );
    return result;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const deleteData = async (data) => {
  try {
    const folder = await models.Folder.findOne({ where: { id: data.id } });
    if (!folder) throw new Error("No data found");

    const result = await models.Folder.destroy({
      where: { id: data.id },
    });
    return result;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const fetchImages = async (id) => {
  try {
    const folder = await models.Folder.findByPk(id, {
      include: [
        {
          model: models.Image,
          as: "images",
        },
      ],
    });
    if (!folder) throw new Error("No folder found");

    // Add public URLs to each image in the folder
    const imagesWithUrls = folder.images.map((img) => ({
      ...img.dataValues,
      original_url: `${BASE_URL}/${img.original_path}`,
      optimized_url: `${BASE_URL}/${img.optimized_path}`,
    }));

    return { ...folder.dataValues, images: imagesWithUrls };
  } catch (error) {
    throw new Error(error.message);
  }
};
