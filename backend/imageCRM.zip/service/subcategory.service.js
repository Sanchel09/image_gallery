import models from "../models/index";

export const get = async () => {
  try {
    const subCategories = await models.SubCategory.findAll({
      include: [
        {
          model: models.Category,
          as: "category",
        },
        {
          model: models.SubCategory,
          as: "parentSubCategory",
        },
        {
          model: models.SubCategory,
          as: "childrenSubCategories",
        },
      ],
    });
    return subCategories;
  } catch (error) {
    throw new Error(error.message);
  }
};

export const insert = async (data) => {
  try {
    // Using for...of to handle async operations sequentially
    await models.SubCategory.create({
      name: data.name,
      description: data.description,
      parent_id: data.parent_id,
      category_id: data.category_id,
    });
    return { message: "Data has been successfully inserted" };
  } catch (err) {
    throw new Error(err.message); // Throw error to handle at controller level
  }
};

export const getById = async (data) => {
  try {
    const subCategory = await models.SubCategory.findOne({
      where: { id: data.id },
      include: [
        {
          model: models.Category,
          as: "category",
        },
        {
          model: models.SubCategory,
          as: "subCategory",
        },
      ],
    });
    return subCategory;
  } catch (err) {
    return new Error(err.message);
  }
};

export const updateData = async (data, updateId) => {
  try {
    const subCategory = await models.SubCategory.findOne({
      where: { id: updateId },
    });
    if (subCategory) {
      const result = await models.SubCategory.update(
        {
          name: data.name,
          description: data.description,
          parent_id: data.parent_id,
          category_id: data.category_id,
        },
        { where: { id: updateId } }
      );
      return result;
    } else {
      throw new Error("No data found");
    }
  } catch (err) {
    throw new Error(err.message);
  }
};

export const deleteData = async (data) => {
  try {
    const subCategory = await models.SubCategory.findOne({
      where: { id: data.id },
    });
    if (!subCategory) throw new Error("No data found");
    const result = await models.SubCategory.destroy({
      where: { id: data.id },
    });
    return result;
  } catch (err) {
    throw new Error(err.message);
  }
};

export const fetchFolders = async (id) => {
  try {
    const subCategory = await models.SubCategory.findByPk(id, {
      include: [
        {
          model: models.Folder,
          as: "folders",
        },
      ],
    });
    if (!subCategory) throw new Error("No Sub Category found");
    return subCategory;
  } catch (error) {
    throw new Error(error.message);
  }
};
