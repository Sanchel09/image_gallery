import express from "express";
import {
  deleteCategory,
  getCategories,
  getCategoryById,
  getFoldersByCategory,
  getSubCategoriesByCategory,
  insertCategories,
  updateCategory,
} from "../controllers/category.controller";
import { authenticate } from "../middleware/auth.middleware";

const router = express.Router();

router
  .get("/", authenticate, getCategories)
  .post("/", authenticate, insertCategories)
  .get("/:id", authenticate, getCategoryById)
  .delete("/:id", authenticate, deleteCategory)
  .put("/:id", authenticate, updateCategory)
  .post("/subcategories", getSubCategoriesByCategory)
  .post("/folders", authenticate, getFoldersByCategory);

export default router;
